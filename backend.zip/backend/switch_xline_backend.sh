#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "请使用 sudo $0 {ws3|cyg|status}" >&2
  exit 1
fi

stop_if_known() {
  local unit=$1
  if systemctl list-unit-files --type=service --no-legend | awk '{print $1}' | grep -Fxq "$unit"; then
    systemctl stop "$unit" || true
    systemctl disable "$unit" 2>/dev/null || true
  fi
}

start_required() {
  local unit=$1
  if ! systemctl list-unit-files --type=service --no-legend | awk '{print $1}' | grep -Fxq "$unit"; then
    echo "缺少 systemd 服务：$unit" >&2
    exit 2
  fi
  systemctl enable --now "$unit"
}

show_status() {
  systemctl --no-pager --plain is-active \
    xline-app-backend1.service \
    xline-cyg-runtime.service \
    xline-cyg-app-backend.service 2>/dev/null || true
  ss -lntp | grep ':8000' || true
}

case "${1:-}" in
  ws3)
    stop_if_known xline-cyg-app-backend.service
    stop_if_known xline-cyg-runtime.service
    stop_if_known xline-app-backend.service
    start_required xline-app-backend1.service
    ;;
  cyg)
    stop_if_known xline-app-backend1.service
    stop_if_known xline-app-backend.service
    start_required xline-cyg-runtime.service
    start_required xline-cyg-app-backend.service
    ;;
  status)
    show_status
    exit 0
    ;;
  *)
    echo "用法：sudo $0 {ws3|cyg|status}" >&2
    exit 1
    ;;
esac

sleep 3
show_status
