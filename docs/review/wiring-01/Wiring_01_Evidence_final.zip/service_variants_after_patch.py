"""Post-patch service probe: positive and five negative variants."""
import json
import tempfile
from pathlib import Path

from tests.test_wiring_01_evidence_consumption import (
    POSITIVE_SOURCE, _circle_steps, _envelope, _run,
)

variants = {
    "positive": POSITIVE_SOURCE,
    "unknown_clause_semicolon": POSITIVE_SOURCE + "；嘴巴为一条微笑曲线",
    "unknown_clause_comma": POSITIVE_SOURCE + "，嘴巴为一条微笑曲线",
}
for name, kwargs in {
    "wrong_dimension": {"wrong_radius": True},
    "missing_object": {"missing_last": True},
    "wrong_binding": {"wrong_binding": True},
}.items():
    variants[name] = POSITIVE_SOURCE
    variants[name + "__kwargs"] = kwargs

out = []
base = Path(tempfile.mkdtemp())
for name, source in variants.items():
    if name.endswith("__kwargs"):
        continue
    kwargs = variants.get(name + "__kwargs", {})
    result, state = _run(base / name, source, [_envelope(source, _circle_steps(**kwargs))], name)
    record = result.get("variant", {}).get("construction_record", {})
    source_acceptance = record.get("source_acceptance", {})
    scope = source_acceptance.get("scope_evidence", {})
    unresolved = [e.get("unresolved_evidence") for e in scope.get("entries", []) if e.get("unresolved_evidence")]
    out.append({
        "variant": name,
        "outlet_calls": state["outlet_calls"],
        "draft_count": state["draft_count"],
        "accepted_count": state["accepted_count"],
        "accepted": state["accepted"],
        "source_status": source_acceptance.get("status"),
        "source_coverage": source_acceptance.get("coverage"),
        "inventory_scope": source_acceptance.get("inventory_scope"),
        "scope_state": scope.get("state"),
        "scope_reasons": scope.get("reasons"),
        "unresolved_evidence": unresolved,
        "acceptance_summary": result.get("acceptance_summary"),
        "variant_id": result.get("variant", {}).get("id"),
    })

Path(__file__).with_name("service_variants_after_patch.txt").write_text(
    "\n".join(json.dumps(item, ensure_ascii=False) for item in out) + "\n",
    encoding="utf-8",
)
print(f"wrote {len(out)} probe records")
